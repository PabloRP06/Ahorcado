// =======================================================
// LÓGICA DEL JUEGO
// =======================================================

const WORDS = [
    "PROGRAMACION", "JAVASCRIPT", "GITHUB", "REPOSITORIO", 
    "CODIGO", "COMPUTADORA", "FRAMEWORK", "VARIABLE"
];
const MAX_FALLOS = 6; 

let secretWord = '';
let guessedWord = [];
let wrongGuesses = [];
let remainingFalls = MAX_FALLOS;

// Referencias del DOM
const wordDisplay = document.getElementById('word-display');
const wrongLettersDisplay = document.getElementById('wrong-letters');
const keyboard = document.getElementById('keyboard');
const hangmanDisplay = document.getElementById('hangman-display');
const messageDisplay = document.getElementById('message');
const restartButton = document.getElementById('restart-button');

// Función para inicializar o reiniciar el juego
function startGame() {
    // 1. Resetear variables
    secretWord = WORDS[Math.floor(Math.random() * WORDS.length)];
    guessedWord = Array(secretWord.length).fill('_');
    wrongGuesses = [];
    remainingFalls = MAX_FALLOS;
    
    // 2. Limpiar la interfaz
    messageDisplay.textContent = '';
    restartButton.style.display = 'none';
    keyboard.innerHTML = '';
    hangmanDisplay.className = 'hangman-display'; // Resetear dibujo
    
    updateDisplay();
    createKeyboard();
}

// Función para actualizar la interfaz del juego
function updateDisplay() {
    wordDisplay.textContent = guessedWord.join(' ');
    wrongLettersDisplay.textContent = wrongGuesses.join(', ');

    // Actualizar el muñeco (añadimos una clase CSS por cada fallo)
    hangmanDisplay.className = `hangman-display fallo-${wrongGuesses.length}`;
}

// Función para crear el teclado A-Z
function createKeyboard() {
    for (let i = 65; i <= 90; i++) {
        const letter = String.fromCharCode(i);
        const button = document.createElement('button');
        button.textContent = letter;
        button.addEventListener('click', () => handleGuess(letter, button));
        keyboard.appendChild(button);
    }
}

// Función principal que maneja el intento del usuario
function handleGuess(letter, button) {
    if (!secretWord) return; // Si el juego no ha comenzado (o ya terminó)

    button.disabled = true; // Deshabilitar el botón de la letra
    
    if (secretWord.includes(letter)) {
        // Acierto
        for (let i = 0; i < secretWord.length; i++) {
            if (secretWord[i] === letter) {
                guessedWord[i] = letter;
            }
        }
        button.classList.add('correct');
    } else {
        // Fallo
        wrongGuesses.push(letter);
        button.classList.add('wrong');
        remainingFalls--;
    }

    updateDisplay();
    checkGameStatus();
}

// Función para verificar si el juego terminó (ganó o perdió)
function checkGameStatus() {
    const currentWord = guessedWord.join('');

    if (currentWord === secretWord) {
        // GANÓ
        messageDisplay.textContent = '¡Felicidades! ¡Has salvado al muñeco!';
        endGame(true);
    } else if (remainingFalls === 0) {
        // PERDIÓ
        messageDisplay.textContent = `¡Perdiste! La palabra era: ${secretWord}`;
        endGame(false);
    }
}

// Función para finalizar el juego
function endGame(win) {
    // Deshabilitar todo el teclado
    Array.from(keyboard.children).forEach(btn => btn.disabled = true);
    restartButton.style.display = 'block';
    // Si perdió, asegurar que el muñeco esté completo
    if (!win) {
         hangmanDisplay.className = `hangman-display fallo-${MAX_FALLOS}`;
    }
}

// Inicializar el juego y añadir el listener al botón de reiniciar
startGame();
restartButton.addEventListener('click', startGame);